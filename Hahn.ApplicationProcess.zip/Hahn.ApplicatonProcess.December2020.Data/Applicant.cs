﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data
{
    public class Applicant
    {
        private bool defVal = false;
        public int ID { get; set; }
        public string Name { get; set; }
        public string FamilyName { get; set; }
        public string Address { get; set; }
        public string CountryOfOrigin { get; set; }
        public string EMailAdress { get; set; }
        public int Age { get; set; }
        public bool Hired
        {
            get
            {
                return defVal; //defaults hired to false
            }
            set
            {
                defVal = value;
            }
        }

    }

    public static class Globals
    {
        static Applicant applicant0 = new Applicant
        {
            ID = 0,
            Name = "Peter",
            FamilyName = "Maier",
            Address = "Alexanderplatz 1",
            CountryOfOrigin = "Germany",
            EMailAdress = "test@gmail.com",
            Age = 35
        };

        static Applicant applicant1 = new Applicant
        {
            ID = 1,
            Name = "Johannes",
            FamilyName = "Gut",
            Address = "Roter Platz 1",
            CountryOfOrigin = "Russland",
            EMailAdress = "test@gmail.ru",
            Age = 31
        };

        public static List<Applicant> ApplicantList = new List<Applicant>() { applicant0, applicant1};
    }
}
