require('bootstrap/dist/css/bootstrap.min.css');
require('bootstrap');
import {RouterConfiguration, Router} from 'aurelia-router';
import { PLATFORM } from "aurelia-pal";

export class App {
  router: Router;

  configureRouter(config: RouterConfiguration, router: Router): void {

    config.title = 'Hahn';
    config.map([
      { route: '', moduleId: PLATFORM.moduleName("components/app-form"), name: 'form',    nav: true,   title: 'Form' },
      { route: '/applicant_created_successfully', moduleId: PLATFORM.moduleName("components/confirm-page"), name: 'conf',    nav: true,   title: 'Success' }

    ]);
    this.router = router;

  }
}
