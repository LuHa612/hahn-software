
export class Header {    
  appTitle = "Applicants";


}