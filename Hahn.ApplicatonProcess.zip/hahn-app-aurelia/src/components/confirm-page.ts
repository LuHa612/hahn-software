import {RouterConfiguration, Router} from 'aurelia-router';
import {inject, NewInstance} from 'aurelia-dependency-injection';

@inject(Router)


export class ConfirmPage {
  message: string;
  router:Router;

  constructor(router:Router) {
    this.message = 'Hello world';
    this.router = router;
  }

  back(){
    this.router.navigate("");
  }
}
