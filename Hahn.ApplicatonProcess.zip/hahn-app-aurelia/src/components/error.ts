import {DialogController} from 'aurelia-dialog';
  
export class Error {
  message:string;
  static inject = [DialogController];
  controller:DialogController;
  constructor(controller){
    this.controller = controller;
  }
  activate(message){
    this.message = message;
  }

}


