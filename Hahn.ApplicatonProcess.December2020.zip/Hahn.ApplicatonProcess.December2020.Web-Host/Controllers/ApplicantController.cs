﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Data;
using HahnApplicant = Hahn.ApplicatonProcess.December2020.Data.Applicant;
using ApplicantValidator = Hahn.ApplicatonProcess.December2020.Domain.HahnLogic.ApplicantValidator;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Http.Cors;
using Newtonsoft.Json;
using System.Collections.Generic;




// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Hahn.ApplicatonProcess.December2020.Web_Host
{
    [EnableCors(origins: "http://localhost:5000/api/applicant", headers: "*", methods: "*")]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ApplicantController : ControllerBase
    {

        private readonly ILogger<ApplicantController> _logger;

        public ApplicantController(ILogger<ApplicantController> logger)
        {
            _logger = logger;
        }

        // GET api/<ApplicantController>
        /// <summary>
        /// Gets a all Applicants.
        /// </summary>
        [HttpGet]
        [ProducesResponseType(201, Type = typeof(HahnApplicant[]))]
        [ProducesResponseType(400, Type = typeof(HTTP_Result))]
        public dynamic Get()
        {

            try
            {
                DataTable dt = GetData();
                List<HahnApplicant> applicants = new List<HahnApplicant>();

                int i = 0;
                for (i = 0; i < dt.Rows.Count; i++)
                {
                    applicants.Add(toApplicant(dt.Rows[i]));
                }

                Response.StatusCode = 201;
                return applicants;
            }
            catch
            {
                HTTP_Result resError = new HTTP_Result()
                {
                    status = "error",
                    method = "GET",
                    errorMessage = "Could not return Applicant List"
                };
                return resError;
            }

        }



        // GET api/<ApplicantController>/5
        /// <summary>
        /// Gets a specific Applicant.
        /// </summary>
        /// <param name="id" example="1"></param>  
        [HttpGet("{id}")]
        [ProducesResponseType(201, Type = typeof(HahnApplicant))]
        [ProducesResponseType(400, Type = typeof(HTTP_Result))]
        public dynamic Get(int id)
        {
            DataTable dt = GetData();
            HahnApplicant applicant = new HahnApplicant();


            int i = 0; bool containsID = false;

            for (i = 0; i < dt.Rows.Count; i++)
            {
                if ((int)dt.Rows[i][0] == id)
                {
                    containsID = true;
                    applicant = toApplicant(dt.Rows[i]);
                }
            }
            if (!containsID)
            {
                Response.StatusCode = 400;
                string errorMessage = "ArgumentException_GET: ID does not exist";
                _logger.LogError(errorMessage);
                HTTP_Result resError = new HTTP_Result()
                {
                    status = "error",
                    method = "GET",
                    errorMessage = errorMessage
                };

                return resError;
            }

            Response.StatusCode = 201;
            return applicant;
        }

        // POST api/<ApplicantController>
        /// <summary>
        /// Add a new Applicant to the Database.
        /// </summary>

        /// <returns>A the URL to the newly created Applicant</returns>
        /// <response code="201">Returns the newly created item</response>
        /// <response code="400">Returns Error Message</response>  
        [HttpPost]
        [ProducesResponseType(201, Type = typeof(HTTP_Result))]
        [ProducesResponseType(400, Type = typeof(HTTP_Result))]
        public HTTP_Result Post([FromBody] HahnApplicant applicant)
        {
            ApplicantValidator validator = new ApplicantValidator();
            DataTable dt = GetData();
            int i = 0; bool containsID = false;

            for (i = 0; i < dt.Rows.Count; i++)
            {
                if ((int)dt.Rows[i][0] == applicant.ID)
                {
                    containsID = true;
                }
            }

            if (!validator.Validate(applicant).IsValid)
            {
                string errorMessage = "ArgumentException POST: ";
                foreach (var failure in validator.Validate(applicant).Errors)
                {
                   errorMessage += ("Property " + failure.PropertyName + " failed validation. Error was: " + failure.ErrorMessage) + ". ";
                }
                Response.StatusCode = 400;
                _logger.LogError(errorMessage);
                HTTP_Result resError = new HTTP_Result()
                {
                    status = "error",
                    method = "POST",
                    errorMessage = errorMessage
                };

                return resError;
            }
            else if (containsID)
            {
                int nextAvailable = this.checkForNextAvailable(dt);
                Response.StatusCode = 400;
                string errorMessage = "ID is already taken, next available ID: " + nextAvailable.ToString();
                _logger.LogError(errorMessage);
                HTTP_Result resError = new HTTP_Result()
                {
                    status = "error",
                    method = "POST",
                    errorMessage = errorMessage
                };
                return resError;
            }
            try
            {
                PostData(applicant);
            }
            catch(Exception ex)
            {
                string errorMessage = ex.Message;
                Response.StatusCode = 400;
                _logger.LogError(errorMessage);
                HTTP_Result resError = new HTTP_Result()
                {
                    status = "error",
                    method = "POST",
                    errorMessage = errorMessage
                };
                return resError;
            }

            Response.StatusCode = 201;

            HTTP_Result res = new HTTP_Result()
            {
                status = "success",
                method = "POST",
                url = "http://localhost:5000/api/applicant/" + applicant.ID
            };

            return res;
        }

        // PUT api/<ApplicantController>/5
        /// <summary>
        /// Edits an Applicant in the Database.
        /// </summary>

        /// <param name="id" example="10"></param>   
        /// <param name="applicant"></param>   
        /// <returns>A the URL to the newly created Applicant</returns>
        /// <response code="201">Returns the newly created item</response>
        /// <response code="400">Returns Error Message</response>  
        [HttpPut("{id}")]
        [ProducesResponseType(201, Type = typeof(HTTP_Result))]
        [ProducesResponseType(400, Type = typeof(HTTP_Result))]
        public HTTP_Result Put(int id, [FromBody] HahnApplicant applicant)
        { 
            ApplicantValidator validator = new ApplicantValidator();

            if (!validator.Validate(applicant).IsValid)
            {
                string errorMessage = "ArgumentException PUT: ";
                foreach (var failure in validator.Validate(applicant).Errors)
                {
                    errorMessage += ("Property " + failure.PropertyName + " failed validation. Error was: " + failure.ErrorMessage) + "\n";
                }
                Response.StatusCode = 400;
                _logger.LogError(errorMessage);

                HTTP_Result resError = new HTTP_Result()
                {
                    status = "error",
                    method = "PUT",
                    errorMessage = errorMessage
                };

                return resError;
            }

            DataTable dt = GetData();
            int i = 0; bool containsID = false;

            for (i = 0; i < dt.Rows.Count; i++)
            {
                if ((int)dt.Rows[i][0] == id)
                {
                    containsID = true;
                }
            }


            if (!containsID)
            {
                Response.StatusCode = 400;
                string errorMessage = "ArgumentException_PUT: ID does not exist";
                _logger.LogError(errorMessage);

                HTTP_Result resError = new HTTP_Result()
                {
                    status = "error",
                    method = "PUT",
                    errorMessage = errorMessage
                };

                return resError;
            }

            try
            {
                PutData(id, applicant);
                Response.StatusCode = 201;

                HTTP_Result res = new HTTP_Result()
                {
                    status = "success",
                    method = "PUT",
                    url = "http://localhost:5000/api/applicant/" + applicant.ID
                };

                return res;
            }
            catch (Exception ex)
            {
                string errorMessage = ex.Message;
                Response.StatusCode = 400;
                _logger.LogError(errorMessage);
                HTTP_Result resError = new HTTP_Result()
                {
                    status = "error",
                    method = "PUT",
                    errorMessage = errorMessage
                };
                return resError;
            }


        }

        // DELETE api/<ApplicantController>/5
        /// <summary>
        /// Deletes a specific Applicant.
        /// </summary>
        /// <param name="id" example="10"></param>  
        [HttpDelete("{id}")]
        [ProducesResponseType(201, Type = typeof(HTTP_Result))]
        [ProducesResponseType(400, Type = typeof(HTTP_Result))]
        public HTTP_Result Delete(int id)
        {
            DataTable dt = GetData();
            int i = 0; bool containsID = false;

            for (i = 0; i < dt.Rows.Count; i++)
            {
                if ((int)dt.Rows[i][0] == id)
                {
                    containsID = true;
                }
            }
            if (!containsID)
            {
                Response.StatusCode = 400;
                string errorMessage = "ArgumentException_DELETE: ID does not exist";
                _logger.LogError(errorMessage);

                HTTP_Result resError = new HTTP_Result()
                {
                    status = "error",
                    method = "DELETE",
                    errorMessage = errorMessage
                };

                return resError;
            }
            try
            {
                DelData(id);
                Response.StatusCode = 201;

                HTTP_Result res = new HTTP_Result()
                {
                    status = "success",
                    method = "DELETE",
                    url = "localhost:5001/api/applicant/" + id
                };

                return res;
            }
            catch(Exception ex)
            {
                Response.StatusCode = 400;
                string errorMessage = ex.Message;
                _logger.LogError(errorMessage);

                HTTP_Result resError = new HTTP_Result()
                {
                    status = "error",
                    method = "DELETE",
                    errorMessage = errorMessage
                };

                return resError;
            }

        }

        

        internal DataTable GetData()
        {
            string connectionString = "Server=tcp:hahn.database.windows.net,1433;Initial Catalog=hahndb;Persist Security Info=False;User ID=LuHa;Password=HahnApp1995;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            string query = "SELECT * FROM [dbo].[applicant_list] ORDER BY ID";
            SqlCommand cmd = new SqlCommand(query, conn);

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            conn.Close();
            return dt;
        }

        internal void PostData(HahnApplicant applicant)
        {
            string connectionString = "Server=tcp:hahn.database.windows.net,1433;Initial Catalog=hahndb;Persist Security Info=False;User ID=LuHa;Password=HahnApp1995;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            string query = "INSERT INTO [dbo].[applicant_list] VALUES (@param1,@param2,@param3,@param4,@param5,@param6,@param7,@param8);";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = applicant.ID;
                cmd.Parameters.Add("@param2", SqlDbType.NVarChar, 50).Value = applicant.Name;
                cmd.Parameters.Add("@param3", SqlDbType.NVarChar, 50).Value = applicant.FamilyName;
                cmd.Parameters.Add("@param4", SqlDbType.NVarChar, 50).Value = applicant.Address;
                cmd.Parameters.Add("@param5", SqlDbType.NVarChar, 50).Value = applicant.CountryOfOrigin;
                cmd.Parameters.Add("@param6", SqlDbType.NVarChar, 50).Value = applicant.EMailAdress;
                cmd.Parameters.Add("@param7", SqlDbType.Int).Value = applicant.Age;
                cmd.Parameters.Add("@param8", SqlDbType.Bit).Value = applicant.Hired;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                conn.Close();
            }            
        }

        internal void PutData(int putID, HahnApplicant applicant)
        {
            string connectionString = "Server=tcp:hahn.database.windows.net,1433;Initial Catalog=hahndb;Persist Security Info=False;User ID=LuHa;Password=HahnApp1995;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            string query = "UPDATE [dbo].[applicant_list] SET ID=@param1, FirstName=@param2, FamilyName=@param3, _Address=@param4, CountryOfOrigin=@param5, EMailAdress=@param6, Age=@param7, Hired=@param8 WHERE ID=" + putID + ";";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = applicant.ID;
                cmd.Parameters.Add("@param2", SqlDbType.NVarChar, 50).Value = applicant.Name;
                cmd.Parameters.Add("@param3", SqlDbType.NVarChar, 50).Value = applicant.FamilyName;
                cmd.Parameters.Add("@param4", SqlDbType.NVarChar, 50).Value = applicant.Address;
                cmd.Parameters.Add("@param5", SqlDbType.NVarChar, 50).Value = applicant.CountryOfOrigin;
                cmd.Parameters.Add("@param6", SqlDbType.NVarChar, 50).Value = applicant.EMailAdress;
                cmd.Parameters.Add("@param7", SqlDbType.Int).Value = applicant.Age;
                cmd.Parameters.Add("@param8", SqlDbType.Bit).Value = applicant.Hired;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }


        internal void DelData(int delID)
        {
            string connectionString = "Server=tcp:hahn.database.windows.net,1433;Initial Catalog=hahndb;Persist Security Info=False;User ID=LuHa;Password=HahnApp1995;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            string query = "DELETE FROM [dbo].[applicant_list] WHERE ID=" + delID + ";";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        internal int checkForNextAvailable(DataTable dt)
        {
            int i = 0; int u = 0; bool contained = false;

            for(i=0; i < dt.Rows.Count; i++)
            {
                for(u=0; u < dt.Rows.Count; u++)
                {
                    if ((int)dt.Rows[u][0] == i)
                        contained = true;
                }
                if (!contained)
                    return i;
                contained = false;
            }
            return dt.Rows.Count;
        }






        internal HahnApplicant toApplicant(DataRow row)
        {
            HahnApplicant applicant = new HahnApplicant();
            applicant.ID = (int)row[0];
            applicant.Name = row[1].ToString();
            applicant.FamilyName = row[2].ToString();
            applicant.Address = row[3].ToString();
            applicant.CountryOfOrigin = row[4].ToString();
            applicant.EMailAdress = row[5].ToString();
            applicant.Age = (int)row[6];
            applicant.Hired = (bool)row[7];

            return applicant;
        }
    }
    public class HTTP_Result
    {
        public string status { get; set; }
        public string method { get; set; }
        public string url { get; set; }
        public string errorMessage { get; set; }
    }


}
