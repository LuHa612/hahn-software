﻿using System;
using FluentValidation;
using HahnApplicant = Hahn.ApplicatonProcess.December2020.Data.Applicant;
using System.Net.Http;
using System.Net;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace Hahn.ApplicatonProcess.December2020.Domain
{
    public class HahnLogic
    {
        public class ApplicantValidator : AbstractValidator<HahnApplicant>
        {
            public ApplicantValidator()
            {
                RuleFor(x => x.Name).Length(5, 100).WithMessage("Please specify a first name");
                RuleFor(x => x.FamilyName).Length(5, 100).WithMessage("Please specify a family name");
                RuleFor(x => x.Address).Length(5, 100).WithMessage("Please specify an address");
                RuleFor(x => x.CountryOfOrigin).Must(country => BeAValidCountry(country)).WithMessage("Country seems to not exist");
                RuleFor(x => x.EMailAdress).Must(email => BeAValidEMail(email)).WithMessage("E-Mail not valid.");
                RuleFor(x => x.Age).Must(age => BeAValidAge(age)).WithMessage("Must be between 20 and 60");
                RuleFor(x => x.Hired).NotNull().WithMessage("Hired cannot be null");
            }

            public bool BeAValidCountry(string country)
            {
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest
                                           .Create("https://restcountries.eu/rest/v2/name/" + country + "?fullText=true");
                try
                {
                    HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse();
                    return true;
                }
                catch
                {
                    return false;
                }

            }

            public bool BeAValidEMail(string email)
            {
                HttpWebRequest webRequest = (HttpWebRequest)WebRequest
                                           .Create("http://apilayer.net/api/check?access_key=896b42bf09d99a0064d9fd332b2be35d&email="+ email +"&smtp=1&format=1");
                try
                {
                    webRequest.Method = "GET";
                    webRequest.ContentType = "application/json";
                    WebResponse response = webRequest.GetResponse();
                    var responseString = new
                    StreamReader(response.GetResponseStream()).ReadToEnd();
                    dynamic json = JsonConvert.DeserializeObject(responseString);
  
                    if (json.format_valid == true && json.mx_found == true)
                        return true;
                    else
                        return false;
                }
                catch
                {
                    return false;
                }

            }

            public bool BeAValidAge(int age)
            {
                if (age > 19 && age < 61)
                    return true;
                else
                    return false;
            }
        }
    }
}
