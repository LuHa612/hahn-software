import {ConfirmPage} from './confirm-page';
import {DialogService} from 'aurelia-dialog';
import {Prompt} from './prompt';
import {Error} from './error';
import {inject, NewInstance} from 'aurelia-dependency-injection';
import {ValidationControllerFactory, ValidationController, ValidateResult, Validator, RenderInstruction, validateTrigger, ValidationRules} from 'aurelia-validation';
import {PLATFORM} from 'aurelia-pal';
import {I18N} from 'aurelia-i18n';
import {HttpClient} from 'aurelia-fetch-client';
import {RouterConfiguration, Router} from 'aurelia-router';


@inject(ValidationControllerFactory, DialogService, I18N, Router, Validator)
export class AppForm {

  router:Router;
  firstName: string;
  applicant:Applicant;

  _id:number;
  _name:string;
  _familyname:string;
  _address:string;
  _coo:string;
  _email:string;
  _age:number;
  _hired=false;

  applicant_list=[];

  notAllEmpty = false;
  language = "Deutsch";
  canSave:boolean;



  dialogService:DialogService;
  controller:ValidationController;
  validator:Validator;
  i18n:I18N;
  static inject = [DialogService];

  constructor(controllerFactory:ValidationControllerFactory, dialogService:DialogService, i18n:I18N, router:Router, validator:Validator) {
    this.dialogService = dialogService;
    this.router = router;
    this.i18n = i18n;
    this.i18n.tr('error')

    this.canSave = false;
    this.validator = validator;
    this.controller = controllerFactory.createForCurrentScope(validator);

    this.controller.subscribe(event => this.validateWhole());
    this.controller.addRenderer(new BootstrapFormRenderer());


    setTimeout(() => {this.checkForContent(); this.clearForm()}, 1);

    ValidationRules.off;
    ValidationRules
    .ensure("_id").required().withMessage("ID " + this.i18n.tr('required')).min(0).withMessage("ID " + this.i18n.tr('min0'))
    .ensure("_name").required().withMessage(this.i18n.tr('firstName') + " " + this.i18n.tr('required')).minLength(5).withMessage(this.i18n.tr('firstName') + " " + this.i18n.tr('min5'))
    .ensure("_familyname").required().withMessage(this.i18n.tr('lastName') + " " + this.i18n.tr('required')).minLength(5).withMessage(this.i18n.tr('lastName') + " " + this.i18n.tr('min5'))
    .ensure("_address").required().withMessage(this.i18n.tr('address') + " " + this.i18n.tr('required')).minLength(10).withMessage(this.i18n.tr('address') + " " + this.i18n.tr('min10'))
    .ensure("_coo").required().withMessage(this.i18n.tr('coo') + " " + this.i18n.tr('required'))
    .ensure("_email").required().withMessage(this.i18n.tr('email') + " " + this.i18n.tr('required')).email().withMessage(this.i18n.tr('email') + " " + this.i18n.tr('invalid'))
    .ensure("_age").required().withMessage(this.i18n.tr('age') + " " + this.i18n.tr('required')).range(20, 60).withMessage(this.i18n.tr('age') + " " + this.i18n.tr('between'))
    .on(this);

    this.fillTable()
  }

  private validateWhole() {
    this.validator.validateObject(this)
        .then(results => this.canSave = results.every(result => result.valid));
}

  public submitForm() {

   /* this.applicant.id = this._id;
    this.applicant.name = this._name;
    this.applicant.familyname = this._familyname;
    this.applicant.address = this._address;
    this.applicant.coo = this._coo;
    this.applicant.email = this._email;
    this.applicant.age = this._age;
    this.applicant.hired = this._hired;*/

    const applicant = 
      {
      "id":this._id,
      "name":this._name,
      "familyName":this._familyname,
      "address":this._address,
      "countryOfOrigin": this._coo,
      "eMailAdress": this._email,
      "age": this._age,
      "hired":this._hired
      };


    /*this.applicant.id = 3;
    this.applicant.name = "Lukas";
    this.applicant.familyname ="Hans";
    this.applicant.address = "Palma 34";
    this.applicant.coo = "Spain";
    this.applicant.email ="spain@gmail.com";
    this.applicant.age = 25;*/

    let httpClient = new HttpClient();
    
    httpClient.fetch('http://localhost:5000/api/applicant', {
      method: 'POST',
      body: JSON.stringify(applicant)
    })
    .then(response => 
      { 
        document.body.removeChild(div);
        if(response.status == 201){
          this.router.navigate("#/applicant_created_successfully");
        }
        else if(response.status == 400){
          response.json().then(responseJson => this.dialogService.open({ viewModel: Error, model: responseJson.errorMessage, lock: false }));        
        }
        else{
          response.json().then(responseJson => this.dialogService.open({ viewModel: Error, model: "Unknown Error...", lock: false }));        
        }
      })
    .catch(error => {
      document.body.removeChild(div);
      this.dialogService.open({ viewModel: Error, model: error, lock: false });
    });

      let div= document.createElement("div");
      div.className += "overlay";
      div.innerHTML = "<div class='rotating' style='width:200px; margin:0 auto; margin-top:20rem'><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 192 192'><path d='M140 24h8v-8H44v8h8v41.922L89.597 96 52 126.078V168h-8v8h104v-8h-8v-41.922L102.403 96 140 65.922V24zm-8 0v36H60V24h72zM60 168v-5.528l36-18 36 18V168H60zm72-14.472l-36-18-36 18v-23.606l32-25.6V124h8v-19.677l32 25.6v23.605zM67.403 68h57.194L96 90.877 67.403 68z'/></svg></div>";
      document.body.appendChild(div);
  }

  toggleLanguage(){
    if(this.language == "Deutsch"){
      this.i18n.setLocale('de');
      this.language = "English";
    }
    else if(this.language == "English"){
      this.i18n.setLocale('en');
      this.language = "Deutsch";
    }

    ValidationRules.off;
    ValidationRules
    .ensure("_id").required().withMessage("ID " + this.i18n.tr('required')).min(0).withMessage("ID " + this.i18n.tr('min0'))
    .ensure("_name").required().withMessage(this.i18n.tr('firstName') + " " + this.i18n.tr('required')).minLength(5).withMessage(this.i18n.tr('firstName') + " " + this.i18n.tr('min5'))
    .ensure("_familyname").required().withMessage(this.i18n.tr('lastName') + " " + this.i18n.tr('required')).minLength(5).withMessage(this.i18n.tr('lastName') + " " + this.i18n.tr('min5'))
    .ensure("_address").required().withMessage(this.i18n.tr('address') + " " + this.i18n.tr('required')).minLength(10).withMessage(this.i18n.tr('address') + " " + this.i18n.tr('min10'))
    .ensure("_coo").required().withMessage(this.i18n.tr('coo') + " " + this.i18n.tr('required'))
    .ensure("_email").required().withMessage(this.i18n.tr('email') + " " + this.i18n.tr('required')).email().withMessage(this.i18n.tr('email') + " " + this.i18n.tr('invalid'))
    .ensure("_age").required().withMessage(this.i18n.tr('age') + " " + this.i18n.tr('required')).range(20, 60).withMessage(this.i18n.tr('age') + " " + this.i18n.tr('between'))
    .on(this);
    this.controller.validate();

  }

  checkForContent(){
    let elements = document.getElementsByTagName('input');
    for (let i = 0, len = elements.length; i < len; i++) {
      if(elements[i].value != "" || elements[i].checked == true){
        this.notAllEmpty = true;
        return;
      }
    }
    this.notAllEmpty = false;
  }

  clearForm(){
    let elements = document.getElementsByTagName('input');
    for (let i = 0, len = elements.length; i < len; i++) {
      elements[i].value = "";
      elements[i].checked = false;
    }
    this.notAllEmpty = false;
  }


  resetForm(){
      this.dialogService.open({ viewModel: Prompt, lock: false }).whenClosed(response => {
        if (!response.wasCancelled) {
          //Clear Form
          this.clearForm();
        } else {
          //Nothing
        }
      });
  }

  fillTable(){
    let client = new HttpClient();

    return client.fetch('http://localhost:5000/api/applicant')
        .then(response => response.json())
        .then(users => {this.applicant_list = users; console.log(users)});

  }
}


  export class BootstrapFormRenderer2 {
  render(instruction) {
    try{
    for (let { error, elements } of instruction.unrender) {
      for (let element of elements) {
        this.remove(element, error);
      }
    }

    for (let { result, elements } of instruction.render) {
      for (let element of elements) {
        this.add(element, result);
      }
    }
  }
  catch{
    // when routing
  }
}

  add(element, result:ValidateResult) {
    const formGroup = element.closest('.form-group');
    if (!formGroup) {
      return;
    }
    if (result.valid) {
      return;
    }

    // add the has-error class to the enclosing form-group div
    formGroup.classList.add('has-error');

    // add help-block
    const div = document.getElementById(element.id);
    div.classList.add('red-border');
  }

  remove(element, error) {
    const formGroup = element.closest('.form-group');
    if (!formGroup) {
      return;
    }
    const div = document.getElementById(element.id);
    div.classList.remove('red-border');

  }
}

export class BootstrapFormRenderer {
  render(instruction: RenderInstruction) {
    for (let { result, elements } of instruction.unrender) {
      for (let element of elements) {
        this.remove(element, result);
      }
    }

    for (let { result, elements } of instruction.render) {
      for (let element of elements) {
        this.add(element, result);
      }
    }
  }

  add(element: Element, result: ValidateResult) {
    const formGroup = element.closest('.form-group');
    if (!formGroup) {
      return;
    }

    if (result.valid) {
      if (!formGroup.classList.contains('has-error')) {
        formGroup.classList.add('has-success');
      }
    } else {
      // add the has-error class to the enclosing form-group div
      formGroup.classList.remove('has-success');
      formGroup.classList.add('has-error');

      const div = document.getElementById(element.id);
      div.classList.add('red-border');
      // add help-block
      const message = document.createElement('span');
      message.className = 'help-block validation-message';
      message.textContent = result.message;
      message.id = `validation-message-${result.id}`;
      formGroup.appendChild(message);
    }
  }

  remove(element: Element, result: ValidateResult) {
    const formGroup = element.closest('.form-group');
    if (!formGroup) {
      return;
    }

    if (result.valid) {
      if (formGroup.classList.contains('has-success')) {
        formGroup.classList.remove('has-success');
      }
    } else {
      const div = document.getElementById(element.id);
      div.classList.remove('red-border');
      // remove help-block
      const message = formGroup.querySelector(`#validation-message-${result.id}`);
      if (message) {
        formGroup.removeChild(message);

        // remove the has-error class from the enclosing form-group div
        if (formGroup.querySelectorAll('.help-block.validation-message').length === 0) {
          formGroup.classList.remove('has-error');
        }
      }
    }
  }
}



interface Applicant{
  id:number;
  name:string;
  familyname:string;
  address:string;
  coo:string;
  email:string;
  age:number;
  hired:boolean;
}


