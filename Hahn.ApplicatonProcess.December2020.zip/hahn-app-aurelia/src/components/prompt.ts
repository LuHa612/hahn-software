import {DialogController} from 'aurelia-dialog';
  
export class Prompt {
  static inject = [DialogController];
  controller:DialogController;
  constructor(controller){
    this.controller = controller;
  }

}


